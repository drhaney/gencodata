import codata
import formats
import outputs
import cliargs
from gencodata import *
